import xbmcgui
import xbmcvfs
import os

homeDir = xbmcvfs.translatePath('special://home/addons/plugin.video.BluePlay')
img_path = os.path.join(homeDir, 'resources', 'icons', 'qrcode_pix.png')
bg_path = os.path.join(homeDir, 'resources', 'media', 'background_dim.png')

class Donate(xbmcgui.WindowDialog):
    def __init__(self):
        super().__init__()
        try:
            # Pega a resolução da tela
            width = self.getWidth()
            height = self.getHeight()

            # Fundo escurecido dimensionado dinamicamente
            self.dim_background = xbmcgui.ControlImage(0, 0, width, height, bg_path)

            # Centraliza o QR Code
            img_w, img_h = 400, 400
            img_x = (width - img_w) // 2
            img_y = (height - img_h) // 2 - 50

            self.image = xbmcgui.ControlImage(img_x, img_y, img_w, img_h, img_path)

            self.text = xbmcgui.ControlLabel(
                x=100, y=img_y + img_h + 30, width=width - 200, height=25,
                label='[B][COLOR yellow]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/COLOR][/B]'
            )
            self.text2 = xbmcgui.ControlLabel(
                x=100, y=img_y + img_h + 60, width=width - 200, height=25,
                label='[B][COLOR yellow]PRESSIONE VOLTAR PARA SAIR[/COLOR][/B]'
            )

            # Ordem correta
            self.addControl(self.dim_background)
            self.addControl(self.image)
            self.addControl(self.text)
            self.addControl(self.text2)

        except Exception as e:
            xbmcgui.Dialog().notification('Erro Doação', f'Erro: {str(e)}', xbmcgui.NOTIFICATION_ERROR)