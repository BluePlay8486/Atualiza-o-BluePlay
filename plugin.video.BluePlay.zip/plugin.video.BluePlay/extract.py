import zipfile
import xbmcvfs

def extract_zip(zip_path, extract_to_folder):
    """
    Extrai o conteúdo de um arquivo ZIP para a pasta especificada.

    :param zip_path: Caminho completo do arquivo ZIP.
    :param extract_to_folder: Pasta onde os arquivos serão extraídos.
    :return: True se extrair com sucesso, False se der erro.
    """
    try:
        # Abre o ZIP
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Extrai tudo
            zip_ref.extractall(extract_to_folder)
        return True
    except Exception as e:
        print(f"[Extract] Erro ao extrair ZIP: {str(e)}")
        return False