# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import sqlite3
import os
import datetime

# Caminho para o banco de dados do Kodi
dir_database = xbmcvfs.translatePath("special://profile/Database")
db = os.path.join(dir_database, 'Addons33.db')

def log(msg):
    xbmc.log('[DATABASE] {}'.format(msg), xbmc.LOGINFO)

def get_kversion():
    try:
        full_version_info = xbmc.getInfoLabel('System.BuildVersion')
        baseversion = full_version_info.split(".")
        intbase = int(baseversion[0])
        return intbase
    except Exception as e:
        log('Erro ao obter versão do Kodi: {}'.format(e))
        return 0

def delete_id(addon_id):
    try:
        if not os.path.exists(db):
            log('Banco de dados não encontrado.')
            return
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM installed WHERE addonID=?', (addon_id,))
        conn.commit()
        conn.close()
        log('Addon removido: {}'.format(addon_id))
    except Exception as e:
        log('Erro ao deletar addon: {}'.format(e))

def insert_id(addon_id):
    try:
        if not os.path.exists(db):
            log('Banco de dados não encontrado.')
            return
        now = datetime.datetime.now()
        installDate = now.strftime("%Y-%m-%d %H:%M:%S")
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO installed (addonID,enabled,installDate) VALUES(?,?,?)',
                       (addon_id, 1, installDate))
        conn.commit()
        conn.close()
        log('Addon inserido: {}'.format(addon_id))
    except Exception as e:
        log('Erro ao inserir addon: {}'.format(e))

def update_id(addon_id):
    try:
        if not os.path.exists(db):
            log('Banco de dados não encontrado.')
            return
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        cursor.execute('UPDATE installed SET enabled=1 WHERE addonID=?', (addon_id,))
        conn.commit()
        conn.close()
        log('Addon atualizado: {}'.format(addon_id))
    except Exception as e:
        log('Erro ao atualizar addon: {}'.format(e))

def enable_addon(addon_id):
    if get_kversion() > 16:
        delete_id(addon_id)
        insert_id(addon_id)