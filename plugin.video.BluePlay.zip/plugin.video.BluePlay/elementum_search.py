# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def shele():
    dialog = xbmcgui.Dialog()
    bid = dialog.input('Digite o Nome do Filme', '', type=xbmcgui.INPUT_ALPHANUM)
    if bid:
        link = "plugin://plugin.video.elementum/search?q=" + bid
        xbmc.Player().play(link)