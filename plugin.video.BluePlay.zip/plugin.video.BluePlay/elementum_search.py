# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import urllib.parse

def shele():
    dialog = xbmcgui.Dialog()
    query = dialog.input('Digite o Nome do Filme', '', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        query_encoded = urllib.parse.quote(query)
        elementum_url = f"plugin://plugin.video.elementum/search?q={query_encoded}"

        if xbmc.getCondVisibility('System.HasAddon(plugin.video.elementum)'):
            xbmc.executebuiltin(f'RunPlugin({elementum_url})')
        else:
            xbmcgui.Dialog().notification('Elementum não encontrado', 'Instale o Elementum primeiro.', xbmcgui.NOTIFICATION_ERROR)