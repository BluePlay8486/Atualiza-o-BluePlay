import xbmcgui
import xbmcvfs
from six.moves import urllib_request

def download(url, dest):
    dp = xbmcgui.DialogProgress()
    dp.create("BluePlay", "Preparando download...")

    try:
        # Faz a requisição HTTP
        req = urllib_request.Request(url)
        response = urllib_request.urlopen(req, timeout=10)

        total_size = response.getheader('Content-Length')
        if total_size is None:
            total_size = 0
        else:
            total_size = int(total_size.strip())

        bytes_so_far = 0

        # Abre o arquivo para gravar
        with xbmcvfs.File(dest, 'w+b') as out_file:
            while True:
                chunk = response.read(1024 * 32)  # 32 KB por vez
                if not chunk:
                    break
                out_file.write(chunk)
                bytes_so_far += len(chunk)

                # Atualiza progresso
                if total_size > 0:
                    percent = int((bytes_so_far * 100) / total_size)
                    mensagem = f"{int(bytes_so_far/1024)} KB de {int(total_size/1024)} KB"
                else:
                    percent = 0
                    mensagem = f"{int(bytes_so_far/1024)} KB baixados"

                dp.update(percent, mensagem)

                # Se o usuário cancelar
                if dp.iscanceled():
                    dp.close()
                    out_file.close()
                    xbmcvfs.delete(dest)
                    raise Exception("Download cancelado pelo usuário.")

        dp.update(100, "Download concluído!")
        dp.close()

    except Exception as e:
        dp.close()
        # Deleta o arquivo se houver erro
        if xbmcvfs.exists(dest):
            xbmcvfs.delete(dest)
        raise Exception(f"Erro no download: {str(e)}")
